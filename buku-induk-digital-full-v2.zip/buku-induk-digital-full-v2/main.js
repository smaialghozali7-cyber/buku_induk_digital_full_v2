const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');
app.disableHardwareAcceleration();
app.commandLine.appendSwitch('disable-gpu');
app.commandLine.appendSwitch('use-gl', 'swiftshader');
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion');
function createWindow () {
  const win = new BrowserWindow({
    width: 1360, height: 900, minWidth: 1100, minHeight: 740,
    show: false, backgroundColor: '#ffffff',
    icon: path.join(__dirname, 'build', 'icon.ico'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, backgroundThrottling: false }
  });
  win.once('ready-to-show', () => win.show());
  win.loadFile(path.join(__dirname, 'app', 'index.html'));
}
app.whenReady().then(() => { createWindow(); app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); }); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
const menu = Menu.buildFromTemplate([{ label: 'Berkas', submenu: [{ role: 'reload', label: 'Muat Ulang' }, { role: 'toggleDevTools', label: 'Developer Tools' }, { type: 'separator' }, { role: 'quit', label: 'Keluar' }] }]);
Menu.setApplicationMenu(menu);
