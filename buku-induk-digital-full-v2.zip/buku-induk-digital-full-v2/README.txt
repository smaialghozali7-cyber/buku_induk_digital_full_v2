Buku Induk Digital – SMA Islam Al Ghozali (v2 - Logo patch built-in)
1) Extract ZIP
2) run-bukuinduk.bat (npm install -> npm start)
3) Profil Sekolah: upload LOGO/STEMPEL/TTD (sidebar logo langsung berubah)
4) Raport: impor nilai Excel/CSV -> Preview -> Cetak (PDF A4)
