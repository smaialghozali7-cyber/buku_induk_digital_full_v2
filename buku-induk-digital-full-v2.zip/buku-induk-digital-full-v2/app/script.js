
// Storage & State
const KEY = 'bukuIndukDataV2';
const state = loadState();
function loadState(){
  try{ const raw = localStorage.getItem(KEY); if(raw) return JSON.parse(raw); }catch(e){}
  return { settings:{ sekolah:'SMA Islam Al Ghozali', kepalaSekolah:'', logo:'', stempel:'', ttd:'' }, students:[], teachers:[] };
}
function save(){ localStorage.setItem(KEY, JSON.stringify(state)); }

// Utils
const $ = (sel, root=document)=> root.querySelector(sel);
const $$ = (sel, root=document)=> Array.from(root.querySelectorAll(sel));
function uid(){ return Math.random().toString(36).slice(2,9); }
function fileToDataURL(file){ return new Promise((res,rej)=>{ const r=new FileReader(); r.onload=()=>res(r.result); r.onerror=rej; r.readAsDataURL(file); }); }
function inputRow(label, html){ return `<div class="col-4"><label>${label}</label>${html}</div>`; }
function text(v){ return (v??'')+''; }

// Theme
function toggleTheme(){ document.body.classList.toggle('retro'); }

// Routing
function route(name){
  if(name==='identitas') renderIdentitas();
  else if(name==='ortu') renderOrtu();
  else if(name==='riwayat') renderRiwayat();
  else if(name==='prestasi') renderPrestasi();
  else if(name==='kelulusan') renderKelulusan();
  else if(name==='raport') renderRaport();
  else if(name==='profil') renderProfil();
  else if(name==='guru') renderGuru();
}

// Export / Import JSON
function exportJSON(){
  const blob = new Blob([JSON.stringify(state,null,2)], {type:'application/json'});
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'buku-induk-backup.json'; a.click();
}
async function importJSON(ev){
  const f = ev.target.files[0]; if(!f) return;
  const text = await f.text();
  try{
    const data = JSON.parse(text);
    if(!data.students || !data.settings) throw new Error('Format tidak dikenali');
    Object.assign(state, data); save(); alert('Impor berhasil'); route('identitas'); refreshLogo();
  }catch(e){ alert('Gagal impor: '+e.message); }
}

// Views
function renderIdentitas(){
  const v = $('#view');
  const rows = state.students.map((s,i)=>`<tr><td>${i+1}</td><td>${text(s.name)}</td><td>${text(s.nisn)}</td><td>${text(s.gender)}</td><td><button onclick="editStudent('${s.id}')">Edit</button> <button onclick="delStudent('${s.id}')">Hapus</button></td></tr>`).join('');
  v.innerHTML = `
  <div class="card">
    <h3>Identitas Siswa <span class="badge">${state.students.length} siswa</span></h3>
    <div class="actions"><button class="btn" onclick="newStudent()">Tambah Siswa</button></div>
    <table><thead><tr><th>#</th><th>Nama</th><th>NISN</th><th>JK</th><th>Aksi</th></tr></thead><tbody>${rows||'<tr><td colspan=5>Belum ada data</td></tr>'}</tbody></table>
  </div>`;
}
function newStudent(){
  const s = {id:uid(), name:'', nisn:'', birthDate:'', gender:'', address:'', phone:'', email:'', photo:'', parent:{name:'',contact:'',address:''}, edu:{prev:'',yearIn:'',yearOut:''}, achievements:[], status:{type:'',date:'',reason:''}, grades:[]};
  editStudentForm(s,true);
}
function editStudent(id){ const s = state.students.find(x=>x.id===id); if(s) editStudentForm(JSON.parse(JSON.stringify(s)), false); }
function delStudent(id){ if(confirm('Hapus siswa ini?')){ state.students = state.students.filter(s=>s.id!==id); save(); renderIdentitas(); } }
async function editStudentForm(s, isNew){
  const v = $('#view');
  v.innerHTML = `
  <div class="card">
    <h3>${isNew?'Tambah':'Edit'} Siswa</h3>
    <div class="row">
      ${inputRow('Nama', `<input id="f_name" value="${text(s.name)}">`)}
      ${inputRow('NISN', `<input id="f_nisn" value="${text(s.nisn)}">`)}
      ${inputRow('Tanggal Lahir', `<input type="date" id="f_birth" value="${text(s.birthDate)}">`)}
      ${inputRow('Jenis Kelamin', `<select id="f_gender"><option ${s.gender==='L'?'selected':''}>L</option><option ${s.gender==='P'?'selected':''}>P</option></select>`)}
      ${inputRow('Alamat', `<input id="f_addr" value="${text(s.address)}">`)}
      ${inputRow('No HP', `<input id="f_phone" value="${text(s.phone)}">`)}
      ${inputRow('Email', `<input id="f_email" value="${text(s.email)}">`)}
      <div class="col-4"><label>Foto Siswa</label><input type="file" id="f_photo" accept="image/*"><div>${s.photo?`<img src="${s.photo}" style="max-width:120px;border-radius:8px;margin-top:6px">`:''}</div></div>
    </div>
    <div class="actions"><button class="btn" onclick="saveStudent('${s.id}','${isNew}')">Simpan</button><button class="btn" onclick="route('identitas')">Batal</button></div>
  </div>`;
  const file = $('#f_photo'); file && (file.onchange = async (e)=>{ const f=e.target.files[0]; if(f){ s.photo = await fileToDataURL(f); file.nextElementSibling.innerHTML = `<img src="${s.photo}" style="max-width:120px;border-radius:8px;margin-top:6px">`; } });
  window.saveStudent = (id,isNewStr)=>{
    s.name=$('#f_name').value.trim(); s.nisn=$('#f_nisn').value.trim(); s.birthDate=$('#f_birth').value; s.gender=$('#f_gender').value;
    s.address=$('#f_addr').value.trim(); s.phone=$('#f_phone').value.trim(); s.email=$('#f_email').value.trim();
    if(!s.name || !s.nisn){ alert('Nama dan NISN wajib diisi'); return; }
    if(isNewStr==='true'){ state.students.push(s); } else { const i=state.students.findIndex(x=>x.id===id); if(i>=0) state.students[i]=s; }
    save(); alert('Tersimpan'); renderIdentitas();
  };
}

function renderOrtu(){
  const v = $('#view');
  const opt = state.students.map(s=>`<option value="${s.id}">${s.name} (${s.nisn})</option>`).join('');
  v.innerHTML = `
  <div class="card">
    <h3>Data Orang Tua / Wali</h3>
    <div class="row">
      <div class="col-6"><label>Pilih Siswa</label><select id="s_sel"><option value="">-- pilih --</option>${opt}</select></div>
      <div class="col-6"><span class="badge">Isi dan Simpan</span></div>
      ${inputRow('Nama Orang Tua/Wali', `<input id="p_name">`)}
      ${inputRow('Kontak', `<input id="p_contact">`)}
      ${inputRow('Alamat', `<input id="p_addr">`)}
    </div>
    <div class="actions"><button class="btn" onclick="saveOrtu()">Simpan</button></div>
  </div>`;
  $('#s_sel').onchange = (e)=>{ const s = state.students.find(x=>x.id===e.target.value); if(!s) return; $('#p_name').value=s.parent.name||''; $('#p_contact').value=s.parent.contact||''; $('#p_addr').value=s.parent.address||''; };
  window.saveOrtu = ()=>{ const id=$('#s_sel').value; const s=state.students.find(x=>x.id===id); if(!s) return alert('Pilih siswa dahulu'); s.parent.name=$('#p_name').value; s.parent.contact=$('#p_contact').value; s.parent.address=$('#p_addr').value; save(); alert('Tersimpan'); };
}

function renderRiwayat(){
  const v=$('#view');
  const opt = state.students.map(s=>`<option value="${s.id}">${s.name} (${s.nisn})</option>`).join('');
  v.innerHTML = `
  <div class="card">
    <h3>Riwayat Pendidikan</h3>
    <div class="row">
      <div class="col-6"><label>Pilih Siswa</label><select id="s_sel"><option value="">-- pilih --</option>${opt}</select></div>
      ${inputRow('Sekolah Sebelumnya', `<input id="e_prev">`)}
      ${inputRow('Tahun Masuk', `<input id="e_in" type="number" min="1900" max="2100">`)}
      ${inputRow('Tahun Keluar', `<input id="e_out" type="number" min="1900" max="2100">`)}
    </div>
    <div class="actions"><button class="btn" onclick="saveEdu()">Simpan</button></div>
  </div>`;
  $('#s_sel').onchange=(e)=>{ const s=state.students.find(x=>x.id===e.target.value); if(!s)return; $('#e_prev').value=s.edu.prev||''; $('#e_in').value=s.edu.yearIn||''; $('#e_out').value=s.edu.yearOut||''; };
  window.saveEdu=()=>{ const id=$('#s_sel').value; const s=state.students.find(x=>x.id===id); if(!s) return alert('Pilih siswa'); s.edu.prev=$('#e_prev').value; s.edu.yearIn=$('#e_in').value; s.edu.yearOut=$('#e_out').value; save(); alert('Tersimpan'); };
}

function renderPrestasi(){
  const v=$('#view');
  const opt = state.students.map(s=>`<option value="${s.id}">${s.name} (${s.nisn})</option>`).join('');
  v.innerHTML = `
  <div class="card">
    <h3>Prestasi Akademik</h3>
    <div class="row">
      <div class="col-6"><label>Pilih Siswa</label><select id="s_sel"><option value="">-- pilih --</option>${opt}</select></div>
      ${inputRow('Prestasi', `<input id="a_title" placeholder="Contoh: Juara 1 Olimpiade Matematika">`)}
      ${inputRow('Tahun', `<input id="a_year" type="number" min="1900" max="2100">`)}
    </div>
    <div class="actions"><button class="btn" onclick="addAchievement()">Tambah</button></div>
    <div id="a_list" style="margin-top:10px"></div>
  </div>`;
  $('#s_sel').onchange=()=>refreshAchievements();
  window.addAchievement=()=>{ const id=$('#s_sel').value; const s=state.students.find(x=>x.id===id); if(!s) return alert('Pilih siswa'); const t=$('#a_title').value.trim(); const y=$('#a_year').value.trim(); if(!t||!y) return alert('Lengkapi'); s.achievements.push({title:t, year:y}); save(); refreshAchievements(); $('#a_title').value=''; $('#a_year').value=''; };
  function refreshAchievements(){ const id=$('#s_sel').value; const s=state.students.find(x=>x.id===id); if(!s){ $('#a_list').innerHTML=''; return; } const rows=s.achievements.map((p,i)=>`<tr><td>${i+1}</td><td>${p.title}</td><td>${p.year}</td><td><button onclick="delAch('${s.id}',${i})">Hapus</button></td></tr>`).join(''); $('#a_list').innerHTML = `<table><thead><tr><th>#</th><th>Prestasi</th><th>Tahun</th><th>Aksi</th></tr></thead><tbody>${rows||'<tr><td colspan=4>Belum ada</td></tr>'}</tbody></table>`; }
  window.delAch=(sid,idx)=>{ const s=state.students.find(x=>x.id===sid); if(!s)return; s.achievements.splice(idx,1); save(); $('#s_sel').dispatchEvent(new Event('change')); };
}

function renderKelulusan(){
  const v=$('#view');
  const opt = state.students.map(s=>`<option value="${s.id}">${s.name} (${s.nisn})</option>`).join('');
  v.innerHTML = `
  <div class="card">
    <h3>Keterangan Lulus / Pindah</h3>
    <div class="row">
      <div class="col-6"><label>Pilih Siswa</label><select id="s_sel"><option value="">-- pilih --</option>${opt}</select></div>
      ${inputRow('Status', `<select id="st_type"><option>Lulus</option><option>Pindah</option><option>Tidak Lulus</option></select>`)}
      ${inputRow('Tanggal', `<input type="date" id="st_date">`)}
      ${inputRow('Alasan', `<input id="st_reason">`)}
    </div>
    <div class="actions"><button class="btn" onclick="saveStatus()">Simpan</button></div>
  </div>`;
  $('#s_sel').onchange=(e)=>{ const s=state.students.find(x=>x.id===e.target.value); if(!s)return; $('#st_type').value=s.status.type||'Lulus'; $('#st_date').value=s.status.date||''; $('#st_reason').value=s.status.reason||''; };
  window.saveStatus=()=>{ const id=$('#s_sel').value; const s=state.students.find(x=>x.id===id); if(!s)return alert('Pilih siswa'); s.status.type=$('#st_type').value; s.status.date=$('#st_date').value; s.status.reason=$('#st_reason').value; save(); alert('Tersimpan'); };
}

function renderRaport(){
  const v=$('#view');
  const opt = state.students.map(s=>`<option value="${s.id}">${s.name} (${s.nisn})</option>`).join('');
  const gradesTable = `<table id="g_table"><thead><tr><th>Mata Pelajaran</th><th>Semester</th><th>Nilai</th><th>Aksi</th></tr></thead><tbody></tbody></table>`;
  v.innerHTML = `
  <div class="card">
    <h3>Raport Siswa (A4)</h3>
    <div class="row">
      <div class="col-6"><label>Pilih Siswa</label><select id="s_sel"><option value="">-- pilih --</option>${opt}</select></div>
      <div class="col-6"><span class="badge">Impor nilai dari Excel/CSV atau tambah manual</span></div>
      ${inputRow('Mata Pelajaran', `<input id="g_subj">`)}
      ${inputRow('Semester', `<input id="g_sem" type="number" min="1" max="12">`)}
      ${inputRow('Nilai', `<input id="g_score" type="number" min="0" max="100">`)}
    </div>
    <div class="actions">
      <button class="btn" onclick="addGrade()">Tambah Nilai</button>
      <label class="btn" for="fileExcel">Impor Excel/CSV</label>
      <input id="fileExcel" class="hidden" type="file" accept=".xlsx,.xls,.csv" onchange="importGrades(event)">
      <button class="btn" onclick="renderReportPreview()">Preview Raport</button>
      <button class="btn" onclick="window.print()">Cetak (PDF)</button>
    </div>
    <div id="grades" style="margin-top:12px">${gradesTable}</div>
    <div id="raport" class="raport card" style="margin-top:16px"></div>
  </div>`;
  $('#s_sel').onchange = refreshGrades;
  refreshGrades();
  window.addGrade=()=>{ const id=$('#s_sel').value; const s=state.students.find(x=>x.id===id); if(!s) return alert('Pilih siswa'); const subj=$('#g_subj').value.trim(); const sem=$('#g_sem').value.trim(); const sc=$('#g_score').value.trim(); if(!subj||!sem||!sc) return alert('Lengkapi'); s.grades.push({subject:subj,semester:sem,score:+sc}); save(); $('#g_subj').value=''; $('#g_sem').value=''; $('#g_score').value=''; refreshGrades(); };
  window.delGrade=(idx)=>{ const id=$('#s_sel').value; const s=state.students.find(x=>x.id===id); if(!s)return; s.grades.splice(idx,1); save(); refreshGrades(); };
}
function refreshGrades(){
  const id=$('#s_sel')?.value; const s=state.students.find(x=>x.id===id); const tbody = $('#g_table tbody'); if(!tbody) return;
  tbody.innerHTML = s? s.grades.map((g,i)=>`<tr><td>${g.subject}</td><td>${g.semester}</td><td>${g.score}</td><td><button onclick="delGrade(${i})">Hapus</button></td></tr>`).join('') : '';
}
async function importGrades(ev){
  const f = ev.target.files[0]; if(!f) return;
  const id=$('#s_sel').value; const s=state.students.find(x=>x.id===id); if(!s) return alert('Pilih siswa dulu');
  if(f.name.endsWith('.csv')){
    const text = await f.text();
    text.split(/\r?\n/).forEach(line=>{
      const [subject, sem, sc] = line.split(',').map(x=>x?.trim());
      if(subject && sem && sc) s.grades.push({subject, semester: sem, score: +sc});
    });
    save(); refreshGrades(); alert('Impor CSV selesai');
  }else{
    if(typeof XLSX==='undefined'){ alert('Parser Excel tidak tersedia. Pastikan internet aktif untuk memuat SheetJS CDN atau impor file CSV.'); return; }
    const data = new Uint8Array(await f.arrayBuffer());
    const wb = XLSX.read(data, {type:'array'});
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet, {header:1});
    const hdr = rows[0].map(x=> (x||'').toString().toLowerCase().trim());
    const idxSubj = hdr.findIndex(h=>['subject','mata pelajaran','mapel'].includes(h));
    const idxSem = hdr.findIndex(h=>['semester','smtr','smt'].includes(h));
    const idxScore = hdr.findIndex(h=>['score','nilai'].includes(h));
    rows.slice(1).forEach(r=>{
      const subject = idxSubj>=0 ? r[idxSubj] : r[0];
      const sem = idxSem>=0 ? r[idxSem] : r[1];
      const sc = idxScore>=0 ? r[idxScore] : r[2];
      if(subject && sem && sc) s.grades.push({subject:subject.toString(), semester:sem.toString(), score:+sc});
    });
    save(); refreshGrades(); alert('Impor Excel selesai');
  }
}
function renderReportPreview(){
  const id=$('#s_sel')?.value; const s=state.students.find(x=>x.id===id); const div=$('#raport'); if(!div){return}
  if(!s){ div.innerHTML='<div class="notice">Pilih siswa untuk membuat preview raport.</div>'; return; }
  const set = state.settings;
  const ach = (s.achievements||[]).map(a=>`<tr><td>${a.title}</td><td>${a.year}</td></tr>`).join('') || '<tr><td colspan=2>-</td></tr>';
  const grades = (s.grades||[]).map(g=>`<tr><td>${g.subject}</td><td>${g.semester}</td><td style="text-align:center">${g.score}</td></tr>`).join('') || '<tr><td colspan=3>-</td></tr>';
  div.innerHTML = `
  <div style="padding:18px;border:1px solid #c7d6ea;border-radius:12px;background:#fff">
    <div style="display:flex;gap:12px;align-items:center">
      <img src="${set.logo||'logo.png'}" style="width:72px;height:72px;border-radius:50%;border:2px solid #a9bfdf">
      <div>
        <div style="font-size:18px;font-weight:800">${set.sekolah||'SMA Islam Al Ghozali'}</div>
        <div style="font-size:12px;color:#456">RAPORT SEMESTER</div>
      </div>
    </div>
    <hr>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <div>
        <b>Identitas Siswa</b>
        <div>Nama: ${s.name||'-'}</div>
        <div>NISN: ${s.nisn||'-'}</div>
        <div>TTL: ${s.birthDate||'-'}</div>
        <div>Alamat: ${s.address||'-'}</div>
      </div>
      <div>
        <b>Orang Tua/Wali</b>
        <div>Nama: ${s.parent?.name||'-'}</div>
        <div>Kontak: ${s.parent?.contact||'-'}</div>
        <div>Alamat: ${s.parent?.address||'-'}</div>
      </div>
    </div>
    <h4>Nilai</h4>
    <table><thead><tr><th>Mata Pelajaran</th><th>Semester</th><th>Nilai</th></tr></thead><tbody>${grades}</tbody></table>
    <h4>Prestasi</h4>
    <table><thead><tr><th>Prestasi</th><th>Tahun</th></tr></thead><tbody>${ach}</tbody></table>
    <div style="margin-top:28px;display:flex;justify-content:space-between">
      <div></div>
      <div style="text-align:center">
        <div>Mengetahui,</div>
        <div>Kepala Sekolah</div>
        <div style="height:80px;position:relative">
          ${state.settings.stempel?`<img src="${state.settings.stempel}" style="position:absolute;left:-40px;top:0;width:120px;opacity:.45">`:''}
          ${state.settings.ttd?`<img src="${state.settings.ttd}" style="position:absolute;left:20px;top:10px;width:160px;opacity:.85">`:''}
        </div>
        <div style="font-weight:700">${set.kepalaSekolah||'(Nama Kepala Sekolah)'}</div>
      </div>
    </div>
  </div>`;
}

// Profil Sekolah (logo/stempel/ttd upload)
function renderProfil(){
  const v=$('#view');
  v.innerHTML = `
  <div class="card">
    <h3>Profil Sekolah</h3>
    <div class="row">
      ${inputRow('Nama Sekolah', `<input id="sch_name" value="${text(state.settings.sekolah)}">`)}
      ${inputRow('Kepala Sekolah', `<input id="sch_head" value="${text(state.settings.kepalaSekolah)}">`)}
      <div class="col-4"><label>Logo Sekolah</label><input id="sch_logo" type="file" accept="image/*"><div>${state.settings.logo?`<img src="${state.settings.logo}" style="max-width:120px;margin-top:6px;border-radius:8px">`:''}</div></div>
      <div class="col-4"><label>Stempel</label><input id="sch_stamp" type="file" accept="image/*"><div>${state.settings.stempel?`<img src="${state.settings.stempel}" style="max-width:120px;margin-top:6px;border-radius:8px">`:''}</div></div>
      <div class="col-4"><label>TTD Kepala Sekolah</label><input id="sch_sign" type="file" accept="image/*"><div>${state.settings.ttd?`<img src="${state.settings.ttd}" style="max-width:160px;margin-top:6px">`:''}</div></div>
    </div>
    <div class="actions"><button class="btn" onclick="saveProfile()">Simpan</button></div>
  </div>`;
  $('#sch_logo').onchange = async e=>{ const f=e.target.files[0]; if(f){ state.settings.logo = await fileToDataURL(f); save(); e.target.nextElementSibling.innerHTML=`<img src="${state.settings.logo}" style="max-width:120px;margin-top:6px;border-radius:8px">`; refreshLogo(); } };
  $('#sch_stamp').onchange = async e=>{ const f=e.target.files[0]; if(f){ state.settings.stempel = await fileToDataURL(f); save(); e.target.nextElementSibling.innerHTML=`<img src="${state.settings.stempel}" style="max-width:120px;margin-top:6px;border-radius:8px">`; } };
  $('#sch_sign').onchange = async e=>{ const f=e.target.files[0]; if(f){ state.settings.ttd = await fileToDataURL(f); save(); e.target.nextElementSibling.innerHTML=`<img src="${state.settings.ttd}" style="max-width:160px;margin-top:6px">`; } };
  window.saveProfile = ()=>{ state.settings.sekolah=$('#sch_name').value; state.settings.kepalaSekolah=$('#sch_head').value; save(); refreshLogo(); alert('Tersimpan'); };
}

// Guru & Walikelas
function renderGuru(){
  const v=$('#view');
  v.innerHTML = `
  <div class="card">
    <h3>Daftar Guru & Wali Kelas</h3>
    <div class="row">
      ${inputRow('Nama Guru', `<input id="t_name">`)}
      ${inputRow('Mapel', `<input id="t_subject">`)}
      ${inputRow('Wali Kelas', `<input id="t_homeroom" placeholder="contoh: X IPA 1">`)}
      ${inputRow('Kontak', `<input id="t_contact">`)}
    </div>
    <div class="actions">
      <button class="btn" onclick="addTeacher()">Tambah</button>
      <button class="btn" onclick="exportTeachers()">Ekspor Guru (JSON)</button>
    </div>
    <div id="t_list" style="margin-top:10px"></div>
  </div>`;
  refreshTeachers();
  window.addTeacher = ()=>{
    const g = {name:$('#t_name').value.trim(), subject:$('#t_subject').value.trim(), homeroom:$('#t_homeroom').value.trim(), contact:$('#t_contact').value.trim()};
    if(!g.name) return alert('Nama wajib');
    state.teachers.push(g); save(); refreshTeachers();
    ['t_name','t_subject','t_homeroom','t_contact'].forEach(id=>$('#'+id).value='');
  };
  window.delTeacher = (idx)=>{ state.teachers.splice(idx,1); save(); refreshTeachers(); };
  window.exportTeachers = ()=>{
    const blob = new Blob([JSON.stringify(state.teachers,null,2)], {type:'application/json'});
    const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='guru-walikelas.json'; a.click();
  };
}
function refreshTeachers(){
  const rows = state.teachers.map((g,i)=>`<tr><td>${i+1}</td><td>${g.name}</td><td>${g.subject}</td><td>${g.homeroom}</td><td>${g.contact}</td><td><button onclick="delTeacher(${i})">Hapus</button></td></tr>`).join('');
  $('#t_list').innerHTML = `<table><thead><tr><th>#</th><th>Nama</th><th>Mapel</th><th>Wali Kelas</th><th>Kontak</th><th>Aksi</th></tr></thead><tbody>${rows||'<tr><td colspan=6>Belum ada</td></tr>'}</tbody></table>`;
}

// Logo refresh for sidebar
function refreshLogo(){
  const img = document.getElementById('logoImg');
  if(img){ img.src = state.settings.logo || 'logo.png'; }
}

// Init
window.addEventListener('DOMContentLoaded', ()=>{
  refreshLogo();
  // default landing page
  const v = $('#view');
  v.innerHTML = `<div class="notice"><b>Selamat datang.</b> Pilih menu di kiri untuk mulai. Gunakan tombol <em>Ganti Tema</em> untuk Modern/Retro.</div>`;
});
